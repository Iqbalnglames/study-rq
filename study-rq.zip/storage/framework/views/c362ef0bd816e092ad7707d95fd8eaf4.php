
<?php $__env->startSection('dashboardContent'); ?>
    <div class="text-center font-bold p-2 text-lg">  
            <h1>Selamat Datang Kembali  <?php echo e(Auth::user()->name); ?> </h1>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\study-rq\resources\views/teacher/index.blade.php ENDPATH**/ ?>