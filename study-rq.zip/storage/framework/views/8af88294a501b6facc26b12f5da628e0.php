

<?php $__env->startSection('content'); ?>
<?php echo e($post->title); ?>

<?php echo e($post->category->name); ?>

<?php echo $post->body; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\study-rq\resources\views/posts/details.blade.php ENDPATH**/ ?>