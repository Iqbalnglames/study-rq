

<?php $__env->startSection('content'); ?>
<h1 class="font-bold">Seluruh Materi</h1>
<div class="flex justify-center">
    <div class="flex flex-col justify-start w-[60%]">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="posts/<?php echo e($post->slug); ?>">
            <div class="text-left rounded-md bg-white hover:bg-slate-100 p-4 mt-4 drop-shadow-lg">
                <p class="text-lg font-bold" ><?php echo e($post->title); ?></p> 
                <?php if($post->category): ?>
                    <p class="text-sm" ><?php echo e($post->category->name); ?></p>                 
                <?php endif; ?>
            </div>
        </a> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\study-rq\resources\views/posts/index.blade.php ENDPATH**/ ?>