<div>
        <textarea id="myeditorinstance" name="body" placeholder="Mulai tulis disini" >
                  
        </textarea>              
</div><?php /**PATH C:\laragon\www\study-rq\resources\views/components/forms/tinymce-editor.blade.php ENDPATH**/ ?>