<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @yield('header')
    @vite("resources/css/app.css")
    <title>Study Rq</title>
</head>
<body>
    @include('layouts.partials.navbar')
    <div class="pb-4 pt-20">
        <div>
            @yield('content')
        </div>
    </div>
</body>
</html>