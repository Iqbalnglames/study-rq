<div>
    <script src="https://cdn.tiny.cloud/1/6i4xjzmdb00aktaueiwj8bspg0041cl05xdcv49u93qzfm7w/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
  tinymce.init({
    selector: 'textarea#myeditorinstance', // Replace this CSS selector to match the placeholder element for TinyMCE
    plugins: ['code table lists', 'save'],
    hidden_input: false,
    toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | indent outdent | bullist numlist | code | table |save'
  });
</script>
</div>