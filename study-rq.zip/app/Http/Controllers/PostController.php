<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function indexTeacher() 
    {
        return view('teacher.index');
    }

    public function createMateri() 
    {
        $categoryMateri = Category::findOrFail(1);
        return view('teacher.createMateri', [
            'category' => $categoryMateri,
        ]);
    }

    public function storeMateri(Request $request)
    {
        $this->validate($request,[
            'title' => 'required',
            'slug' => 'required',
            'body' => 'required',
        ]);

        Post::create([
            'title' => $request->title,
            'slug' => $request->slug,
            'body' => $request->body,
            'category_id' => $request->category_id,
        ]);

        return redirect('dashboard/create-materi')->with(['success' => 'data berhasil diposting']);

    }
    

    public function showPost()
    {
        $posts = Post::all();
        return view('teacher.postList', compact('posts'));
    }
   
    public function editPost(Post $post)
    {
        $posts = Post::find($post);
        $category = Category::all();
        return view('teacher.editPost', compact('post','category'));
    }
    
    public function updatePost(Request $request, Post $post)
    {
        // $postUpdate = Post::find($post);
        // dd($postUpdate);
        $post->update([
            'title' => $request->title,
            'slug' => $request->slug,
            'body' => $request->body,
            'category_id' => $request->category_id,
        ]);

        return redirect('/dashboard/list-post')->with(['success' => 'data berhasil diupdate']);
    }

    public function indexMateri()
    {
        $posts = Post::all()->where('category_id', 1);
        return view('materi.index', compact('posts'));
    }

    public function showMateri(Post $post)
    {
        $posts = Post::find($post);
        return view('materi.details', compact('post'));
    }

}
