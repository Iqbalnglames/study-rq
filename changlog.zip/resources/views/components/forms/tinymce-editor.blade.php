<div>
        <textarea id="myeditorinstance" name="body" placeholder="Mulai tulis disini" >                
        </textarea>              
</div>