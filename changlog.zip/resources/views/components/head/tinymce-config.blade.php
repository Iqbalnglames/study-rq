<div>
  <script src="https://cdn.tiny.cloud/1/cug785qcedj8vo8xwifx5wl7t6ozm7fhlp9zs3cpfowsn3sj/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
tinymce.init({
  selector: 'textarea#myeditorinstance', // Replace this CSS selector to match the placeholder element for TinyMCE
  plugins: ['code table lists', 'save'],
  hidden_input: false,
  toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | indent outdent | bullist numlist | code | table |save'
});
</script>
</div>