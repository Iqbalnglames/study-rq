<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Study Rq Changelog</title>
</head>
<body>
    <div>
        <h1>Version 1.0.12</h1>
        <ul>
            <li>Redesign Layout for better experience</li>
            <li>Rearrange Material and Class Layouts</li>
            <li>Change Color Pattern for Better looks</li>
            <li>Remove Article Page for Temporary time</li>
        </ul>
        <p style="padding-right: 400px">Website masih dalam tahap pengembangan dan akan terus melakukan improvisasi agar dapat memberikan pengalaman pembelajaran digital yang lebih baik, dukung terus kami dengan menjaga peralatan Lab Komputer serta antusias dalam mengikuti pembelajaran😃</p>
        <a href="/"> <-Kembali ke Halaman  Utama</a>
    </div>
</body>
</html>
    
