@extends('layouts.dashboard_layouts')

@section('content')
<div class="">
    <h1 class="font-semibold text-2xl text-center">List Materi yang sudah diposting</h1>
    <a href="/dashboard/buat-materi" class="p-2 bg-green-600 rounded text-white border border-gray-300">+ Buat Materi</a>     
    <table class="table-auto border border-gray-300 rounded-md mt-4">
        <tr class="font-bold">
            <th class="border bg-slate-100 border-gray-300">Judul</th>
            <th class="border bg-slate-100 border-gray-300">Kelas</th>
            <th class="border bg-slate-100 border-gray-300">Aksi</th>
        </tr>
        @foreach($materials as $material)
        <tr class="">
            <td class="border p-3 border-gray-300"><h1>{{ $material->title }}</h1></td>    
            <td class="border p-3 border-gray-300"><h1>{{ $material->classLevel->name }}</h1></td>    
            <td class="border p-3 uppercase border-gray-300"><a href="#" class="bg-blue-500 p-2 rounded-sm text-white">edit</a> 
                <a href="#" class="bg-red-500 p-2 rounded text-white">delete</a></td>
        </tr>    
        @endforeach
    </table>
</div>
@endsection