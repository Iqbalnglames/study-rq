@extends('layouts.dashboard_layouts')

@section('content')
    <!-- component -->
    <h1>Halo Iqbal</h1>
@endsection