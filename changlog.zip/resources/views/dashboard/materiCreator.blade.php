@extends('layouts.dashboard_layouts')

@section('content')
<form method="POST" action="{{ route('/buat-materi') }}">
    @csrf
    <input type="text" name="title" placeholder="Judul">
    <select name="class_level_id">
        @foreach ($classLevels as $classes)
        <option value="{{$classes->id}}">{{$classes->name}}</option>
        @endforeach
    </select>
    <input id="x" type="hidden" name="body">
    <trix-editor input="x"></trix-editor>
    <button type="submit">Posting Materi</button>
</form>         
@endsection